| corpus | total_statements_before_filter | total_rule_statements_after_filter | pct_kept_as_rules |
| --- | --- | --- | --- |
| Full corpus | 152079 | 2580 | 1.7 |
| Education-relevant | 40957 | 913 | 2.23 |
| Education-in-title | 4604 | 53 | 1.15 |