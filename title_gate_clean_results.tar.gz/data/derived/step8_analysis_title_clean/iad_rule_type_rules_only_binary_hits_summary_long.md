| corpus | rule_type | n_rule_statements_with_hit | pct_rule_statements_with_hit |
| --- | --- | --- | --- |
| Full corpus | boundary | 143 | 5.54 |
| Full corpus | position | 713 | 27.64 |
| Full corpus | choice | 2580 | 100.0 |
| Full corpus | information | 613 | 23.76 |
| Full corpus | scope | 391 | 15.16 |
| Full corpus | aggregation | 79 | 3.06 |
| Full corpus | payoff | 876 | 33.95 |
| Education-relevant | boundary | 83 | 9.09 |
| Education-relevant | position | 336 | 36.8 |
| Education-relevant | choice | 913 | 100.0 |
| Education-relevant | information | 359 | 39.32 |
| Education-relevant | scope | 172 | 18.84 |
| Education-relevant | aggregation | 47 | 5.15 |
| Education-relevant | payoff | 310 | 33.95 |
| Education-in-title | boundary | 3 | 5.66 |
| Education-in-title | position | 17 | 32.08 |
| Education-in-title | choice | 53 | 100.0 |
| Education-in-title | information | 11 | 20.75 |
| Education-in-title | scope | 4 | 7.55 |
| Education-in-title | aggregation | 1 | 1.89 |
| Education-in-title | payoff | 2 | 3.77 |