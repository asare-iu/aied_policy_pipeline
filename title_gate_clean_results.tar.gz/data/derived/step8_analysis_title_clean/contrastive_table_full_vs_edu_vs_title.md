corpus,unique_docs,unique_countries,chunks_total,statements_total,statements_per_100_chunks,explicit_A_pct,implicit_A_pct,any_entity_A_pct,D_present_pct,obligation_pct,permission_pct,prohibition_pct,rule_candidate_pct,norm_candidate_pct,strategy_candidate_pct,other_low_confidence_pct,o_scope_present_pct,stmt_unique_docs
Full corpus,865,79,47512,152079,320.09,83.68,16.28,0.04,59.87,31.83,24.60,3.44,1.70,54.14,40.13,4.03,2.20,856
Education-relevant,671,76,10557,40957,387.96,82.51,17.45,0.05,57.34,33.06,21.43,2.85,2.23,51.28,42.66,3.83,3.15,649
Education-in-title,34,20,1795,4604,256.49,86.49,13.49,0.02,47.11,21.50,22.35,3.26,1.15,41.49,52.89,4.47,1.93,33
