| corpus | iad_rule_type_primary | n | pct |
| --- | --- | --- | --- |
| Full corpus | choice | 846 | 32.79 |
| Full corpus | payoff | 792 | 30.7 |
| Full corpus | information | 361 | 13.99 |
| Full corpus | position | 210 | 8.14 |
| Full corpus | scope | 159 | 6.16 |
| Full corpus | boundary | 143 | 5.54 |
| Full corpus | aggregation | 69 | 2.67 |
| Education-relevant | payoff | 262 | 28.7 |
| Education-relevant | information | 208 | 22.78 |
| Education-relevant | choice | 200 | 21.91 |
| Education-relevant | boundary | 83 | 9.09 |
| Education-relevant | position | 73 | 8.0 |
| Education-relevant | aggregation | 44 | 4.82 |
| Education-relevant | scope | 43 | 4.71 |
| Education-in-title | choice | 27 | 50.94 |
| Education-in-title | information | 9 | 16.98 |
| Education-in-title | position | 9 | 16.98 |
| Education-in-title | boundary | 3 | 5.66 |
| Education-in-title | payoff | 2 | 3.77 |
| Education-in-title | scope | 2 | 3.77 |
| Education-in-title | aggregation | 1 | 1.89 |