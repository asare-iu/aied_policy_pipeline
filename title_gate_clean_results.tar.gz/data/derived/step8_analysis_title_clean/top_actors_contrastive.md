| actor_norm | combined_total | Full corpus | Full corpus % | Full corpus docs | Full corpus actor_col | Education-relevant | Education-relevant % | Education-relevant docs | Education-relevant actor_col | Education-in-title | Education-in-title % | Education-in-title docs | Education-in-title actor_col |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| government | 2885 | 2005 | 1.95 | 160 | a_raw_text | 497 | 1.79 | 81 | a_raw_text | 383 | 11.82 | 4 | a_raw_text |
| commission | 1196 | 860 | 0.84 | 64 | a_raw_text | 326 | 1.17 | 34 | a_raw_text | 10 | 0.31 | 2 | a_raw_text |
| secretary | 1111 | 849 | 0.83 | 11 | a_raw_text | 262 | 0.94 | 5 | a_raw_text | 0 | 0.0 | 0 | nan |
| secretary of defense | 872 | 633 | 0.62 | 7 | a_raw_text | 239 | 0.86 | 6 | a_raw_text | 0 | 0.0 | 0 | nan |
| administrator | 534 | 424 | 0.41 | 8 | a_raw_text | 110 | 0.4 | 5 | a_raw_text | 0 | 0.0 | 0 | nan |
| organization | 378 | 293 | 0.29 | 75 | a_raw_text | 79 | 0.28 | 28 | a_raw_text | 6 | 0.19 | 2 | a_raw_text |
| company | 341 | 284 | 0.28 | 122 | a_raw_text | 54 | 0.19 | 40 | a_raw_text | 3 | 0.09 | 3 | a_raw_text |
| ai systems | 338 | 269 | 0.26 | 102 | a_raw_text | 60 | 0.22 | 30 | a_raw_text | 9 | 0.28 | 2 | a_raw_text |
| data | 334 | 291 | 0.28 | 127 | a_raw_text | 43 | 0.15 | 30 | a_raw_text | 0 | 0.0 | 0 | nan |
| system | 299 | 234 | 0.23 | 111 | a_raw_text | 63 | 0.23 | 37 | a_raw_text | 2 | 0.06 | 2 | a_raw_text |
| controller | 297 | 248 | 0.24 | 26 | a_raw_text | 49 | 0.18 | 15 | a_raw_text | 0 | 0.0 | 0 | nan |
| authority | 296 | 202 | 0.2 | 44 | a_raw_text | 90 | 0.32 | 16 | a_raw_text | 4 | 0.12 | 2 | a_raw_text |
| strategy | 293 | 228 | 0.22 | 93 | a_raw_text | 56 | 0.2 | 31 | a_raw_text | 9 | 0.28 | 4 | a_raw_text |
| programme | 271 | 181 | 0.18 | 60 | a_raw_text | 68 | 0.24 | 31 | a_raw_text | 22 | 0.68 | 3 | a_raw_text |
| agency | 271 | 220 | 0.21 | 40 | a_raw_text | 51 | 0.18 | 18 | a_raw_text | 0 | 0.0 | 0 | nan |
| board | 266 | 215 | 0.21 | 31 | a_raw_text | 51 | 0.18 | 14 | a_raw_text | 0 | 0.0 | 0 | nan |
| united states | 257 | 224 | 0.22 | 20 | a_raw_text | 33 | 0.12 | 6 | a_raw_text | 0 | 0.0 | 0 | nan |
| report | 219 | 143 | 0.14 | 35 | a_raw_text | 72 | 0.26 | 18 | a_raw_text | 4 | 0.12 | 2 | a_raw_text |
| applicant | 215 | 140 | 0.14 | 42 | a_raw_text | 66 | 0.24 | 19 | a_raw_text | 9 | 0.28 | 3 | a_raw_text |
| users | 213 | 185 | 0.18 | 90 | a_raw_text | 24 | 0.09 | 21 | a_raw_text | 4 | 0.12 | 4 | a_raw_text |